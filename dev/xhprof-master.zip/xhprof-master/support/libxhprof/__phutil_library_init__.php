<?php

phutil_register_library('libxhprof', __FILE__);
