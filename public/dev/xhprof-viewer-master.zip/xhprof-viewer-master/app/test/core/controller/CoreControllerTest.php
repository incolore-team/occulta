<?php

namespace app\test\core\controller; 

use \app\test\TestCase;

class CoreControllerTest extends TestCase
{

	
}