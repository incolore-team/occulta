<?php
namespace app\test\core\logger;

use \app\test\TestCase;

class FileLoggerTest extends TestCase
{
    
}
