<?php
namespace app\test\core\i18n;

use \app\test\TestCase;

class I18NProviderTest extends TestCase
{
   
}