<?php

namespace app\test\core\i18n;

use \app\test\TestCase;

class FileMessageSourceTest extends TestCase
{
   
}
