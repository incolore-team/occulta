<?php

namespace app\test\core\caching;

use \app\test\TestCase;

class CacheTest extends TestCase
{
    
}
