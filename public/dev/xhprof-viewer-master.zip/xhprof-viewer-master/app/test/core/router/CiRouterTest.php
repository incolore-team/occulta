<?php
namespace app\test\core\router;

use \app\test\TestCase;

class CiRouterTest extends TestCase
{

}
