<?php

namespace app\test\core\base;

use \app\test\TestCase;

class DiTest extends TestCase
{
   
}
