<?php

namespace app\test\core\db;

use \app\test\TestCase;

class DBTest extends TestCase
{

}