# /bin/bash

cd /path/to/app/
phpunit --bootstrap test/bootstrap.php test/
